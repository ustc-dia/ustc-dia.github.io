function pred = RunInference(images, imageModel, pairwiseModel, tripletModel)
% This function performs inference for a Markov network.
%
% Input:
%   images: A struct array of the images for each character in the word.
%   imageModel: The provided image model.
%   pairwiseModel: The provided pairwise factor model.
%   tripletModel: The provided triplet factor model.
%
% Output:
%   pred: An array of predictions for every variable. In particular,
%     pred(i) is the predicted value for images(i).
%

% Your code here:

end