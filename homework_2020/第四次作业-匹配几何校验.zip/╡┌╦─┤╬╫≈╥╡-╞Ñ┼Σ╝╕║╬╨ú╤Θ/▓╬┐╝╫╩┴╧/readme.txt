--文件夹Batch_SIFT_win32 为 批处理提取DoG SIFT的32位可执行程序。

--DSift Source Code.zip为提取DoG SIFT的c++源代码。

--OpenCV210_reduced.zip 为运行DoG SIFT所必须的Open CV的32位和64位的头文件、库文件等相关文件。具体设置方法请百度，或参考https://www.jianshu.com/p/050d99f80adc。
