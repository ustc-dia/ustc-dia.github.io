--文件夹Batch_SIFT_win32 为 批处理提取DoG SIFT的32位可执行程序。

--DSift Source Code.zip为提取DoG SIFT的c++源代码。如果只是完成本次作业，没有必要看这个代码。这个代码仅供对SFIT代码实现感兴趣的同学参考。

--OpenCV210_reduced.zip 为运行DoG SIFT所必须的Open CV的32位和64位的头文件、库文件等相关文件。具体设置方法请百度，或参考https://blog.csdn.net/c_base_jin/article/details/78787170。
